﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Runtime.Serialization;
using System.Net.Http;
using System.Net.Http.Formatting;
using Newtonsoft.Json;
using System.IO;

namespace IQVIA___Tweet
{
    /// <summary>
    /// This class will retrieve all tweets from 2016 and 2017.
    /// Owner - Vijayan Sivaraman
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main Method to call the service to retrive the tweet data based on the given start and end date
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            GetAllTweet();
        }

        /// <summary>
        /// This method is used to call the URI and header parameters to retrive the tweet data
        /// </summary>
        public static void GetAllTweet()
        {
            HttpClient objClient = new HttpClient();
            objClient.BaseAddress = new Uri("https://badapi.iqvia.io/");
            objClient.DefaultRequestHeaders.Accept.Clear();
            objClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            GetAsyncTweet(objClient).Wait();
        }

        /// <summary>
        /// This Asynchronous method is used to retrive the tweet data and log the data in local file and console window
        /// </summary>
        /// <param name="objCon"></param>
        /// <returns></returns>
        public static async Task GetAsyncTweet(HttpClient objCon)
        {
            // Directory path and file path to log all tweets from 2016 and 2017 to file
            string dirPath = @"C:\IMSHealth1\";
            string filePath = @"C:\IMSHealth1\IQVIATweet.txt";
            List<Tweet> lstTweet = new List<Tweet>();

            // Default datetime for the input parameter start date year 2016
            DateTime date = new DateTime(2016, 01, 01);
            //Added 730 days to the end date parameter for the year 2017
            DateTime finalDate = date.AddDays(730);

            // Check if the directory folder exists in the local drive. If not create the directory for the given path.
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }
            TextWriter txtMirror = new StreamWriter(filePath);
            Console.WriteLine("{0}\t\t\t\t\t\t{1}\t\t\t\t\t\t\t\t{2}", "ID", "STAMP", "TEXT");
            txtMirror.WriteLine("{0}\t\t\t\t\t\t{1}\t\t\t\t\t\t\t\t{2}", "ID", "STAMP", "TEXT");

            while (date <= finalDate)
            {
                DateTime startDate = date;
                // Getting the tweet data fro the period of six days for every iteration
                DateTime endDate = date.AddDays(6);
                // Check if end date is greater than final date then assign final date to end date
                if (endDate > finalDate)
                {
                    endDate = finalDate;
                }
                // Format the start date and end date string
                string strSDate = string.Format("{0}-{1}-{2}T00%3A00%3A00.000z", startDate.Year, startDate.Month, startDate.Day);
                string strEDate = string.Format("{0}-{1}-{2}T00%3A00%3A00.000z", endDate.Year, endDate.Month, endDate.Day);
                string url = string.Format("https://badapi.iqvia.io/api/v1/Tweets?startDate={0}&endDate={1}", strSDate, strEDate);
                var tweets = new HttpClient().GetStringAsync(url);
                date = endDate;
                await Task.WhenAll(tweets);

                // Deserialize the json string to the list object
                lstTweet = JsonConvert.DeserializeObject<List<Tweet>>(tweets.Result);
                foreach (var eachElem in lstTweet)
                {
                    // Displaying the output in console window and logging in the text file.
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", eachElem.Id, eachElem.Stamp, eachElem.Text);

                    // Full tweets are logged in to text file. But in console it is logged only some due to memory size.
                    // Please refer text file for all tweets.
                    txtMirror.WriteLine("{0}\t\t{1}\t\t{2}", eachElem.Id, eachElem.Stamp, eachElem.Text);
                }
            }
            Console.ReadLine();
            //Close or flush the textwriter object.
            txtMirror.Close();
        }
    }


    /// <summary>
    /// Model class which has the tweet properties to get the response from the WEBAPI service
    /// </summary>
    public class Tweet
    {
        public string Id { get; set; }
        public string Stamp { get; set; }
        public string Text { get; set; }
    }
}
